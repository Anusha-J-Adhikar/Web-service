Generate XML using PHP

Following tasks are performed in this article:

 1. Create a database with the name database.

 2. Import the file named db.sql in the database.

 3. Insert values into the databases (optional) to view the xml code. Insertion is also possible in front end.

 4. Open your browser and type:
	localhost/internfinal/index.php